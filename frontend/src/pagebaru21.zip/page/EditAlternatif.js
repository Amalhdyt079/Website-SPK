// // EditAlternative.js
// import React, { useState } from 'react';
// import { Modal, Button, Form, Alert } from 'react-bootstrap';
// import axios from 'axios';

// const EditAlternative = ({ show, onHide, alternative, onUpdate }) => {
//     const [editAlternative, setEditAlternative] = useState(alternative);
//     const [loading, setLoading] = useState(false);
//     const [error, setError] = useState('');
//     const [successMessage, setSuccessMessage] = useState('');

//     const handleInputChange = (e) => {
//         const { name, value } = e.target;
//         setEditAlternative({ ...editAlternative, [name]: value });
//     };

//     const handleEditSubmit = async (e) => {
//         e.preventDefault();
//         if (!editAlternative.nama || !editAlternative.jenis_wisata || !editAlternative.jarak || !editAlternative.harga || !editAlternative.rating) {
//             setError('Semua field harus diisi.');
//             return;
//         }
//         if (editAlternative.rating > 5) {
//             setError('Rating tidak boleh lebih dari 5.');
//             return;
//         }
//         setLoading(true);
//         try {
//             await axios.put(`http://localhost:5000/alternatives/${editAlternative.id_alternatif}`, editAlternative);
//             setSuccessMessage('Alternatif berhasil diperbarui!');
//             onUpdate(); // Call the update function passed from parent
//             onHide(); // Close the modal
//         } catch (error) {
//             setError("Terjadi kesalahan saat memperbarui alternatif!");
//             console.error("Terjadi kesalahan saat memperbarui alternatif!", error);
//         } finally {
//             setLoading(false);
//         }
//     };

//     return (
//         <Modal show={show} onHide={onHide}>
//             <Modal.Header closeButton>
//                 <Modal.Title>Edit Data Alternatif</Modal.Title>
//             </Modal.Header>
//             <Modal.Body>
//                 {error && <Alert variant="danger">{error}</Alert>}
//                 {successMessage && <Alert variant="success">{successMessage}</Alert>}
//                 {editAlternative && (
//                     <Form onSubmit={handleEditSubmit}>
//                         <Form.Group controlId="formEditNama">
//                             <Form.Label>Nama</Form.Label>
//                             <Form.Control
//                                 type="text"
//                                 placeholder="Masukkan nama"
//                                 name="nama"
//                                 value={editAlternative.nama}
//                                 onChange={handleInputChange}
//                                 required
//                             />
//                         </Form.Group>
//                         <Form.Group controlId="formEditJenisWisata">
//                             <Form.Label>Jenis Wisata</Form.Label>
//                             <Form.Select
//                                 name="jenis_wisata"
//                                 value={editAlternative.jenis_wisata}
//                                 onChange={handleInputChange}
//                                 required
//                             >
//                                 <option value="">Pilih Jenis Wisata</option>
//                                 <option value="Wisata Alam">Wisata Alam</option>
//                                 <option value="Wisata Sejarah">Wisata Sejarah</option>
//                                 <option value="Wisata Budaya">Wisata Budaya</option>
//                             </Form.Select>
//                         </Form.Group>
//                         <Form.Group controlId="formEditJarak">
//                             <Form.Label>Jarak (Km)</Form.Label>
//                             <Form.Control
//                                 type="number"
//                                 step="0.1"
//                                 placeholder="Masukkan jarak"
//                                 name="jarak"
//                                 value={editAlternative.jarak}
//                                 onChange={handleInputChange}
//                                 required
//                             />
//                         </Form.Group>
//                         <Form.Group controlId="formEditHarga">
//                             <Form.Label>Harga (Rp)</Form.Label>
//                             <Form.Control
//                                 type="number"
//                                 placeholder="Masukkan harga"
//                                 name="harga"
//                                 value={editAlternative.harga}
//                                 onChange={handleInputChange}
//                                 required
//                             />
//                         </Form.Group>
//                         <Form.Group controlId="formEditRating">
//                             <Form.Label>Rating</Form.Label>
//                             <Form.Control
//                                 type="number"
//                                 step="0.1"
//                                 placeholder="Masukkan rating"
//                                 name="rating"
//                                 value={editAlternative.rating}
//                                 onChange={handleInputChange}
//                                 required
//                             />
//                         </Form.Group>
//                         <br />
//                         <Button variant="primary" type="submit" disabled={loading}>
//                             {loading ? 'Menyimpan...' : 'Simpan Perubahan'}
//                         </Button>
//                     </Form>
//                 )}
//             </Modal.Body>  
//         </Modal>
//     );
// };

// export default EditAlternative;