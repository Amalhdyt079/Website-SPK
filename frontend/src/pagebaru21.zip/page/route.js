import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import RekomendasiObjek from './RekomendasiObjek';
import EditCriterias from './EditCriterias';

const App = () => {
    return (
        <Router>
            <Switch>
                <Route path="/" exact component={RekomendasiObjek} />
                <Route path="/edit-criterias" component={EditCriterias} />
            </Switch>
        </Router>
    );
};

export default App;