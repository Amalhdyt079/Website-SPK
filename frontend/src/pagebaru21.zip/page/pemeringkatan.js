// import React, { useState } from 'react';
// import { Table, Button } from 'react-bootstrap';
// import axios from 'axios';

// const RankingWisata = () => {
//     const [rankings, setRankings] = useState({
//         "Wisata Sejarah": 0,
//         "Wisata Budaya": 0,
//         "Wisata Alam": 0,
//     });

//     const handleRankingChange = (type, value) => {
//         const newValue = parseInt(value, 10);

//         // Check if the new value is valid and unique
//         if (newValue < 1 || newValue > 3) {
//             return; // Ignore invalid values
//         }

//         // Check if the new value already exists in other rankings
//         const existingRankings = Object.values(rankings);
//         if (existingRankings.includes(newValue) && newValue !== rankings[type]) {
//             alert(`Peringkat ${newValue} sudah dipilih untuk jenis wisata lain!`);
//             return; // Prevent setting this ranking
//         }

//         setRankings(prevRankings => ({
//             ...prevRankings,
//             [type]: newValue,
//         }));
//     };

//     const handleSubmit = () => {
//         axios.post('http://localhost:5000/api/rankings', rankings)
//             .then(response => {
//                 console.log(response.data);
//                 alert('Ranking berhasil disimpan!');
//             })
//             .catch(error => {
//                 console.error("Error saving rankings:", error);
//                 alert('Terjadi kesalahan saat menyimpan ranking!');
//             });
//     };

//     // Function to get available rankings
//     const getAvailableRankings = (currentType) => {
//         const usedRanks = Object.entries(rankings)
//             .filter(([type]) => type !== currentType && rankings[type] > 0)
//             .map(([_, rank]) => rank);
        
//         return [1, 2, 3].filter(rank => !usedRanks.includes(rank));
//     };

//     return (
//         <div className="container my-5">
//             <p>Silakan beri peringkat jenis wisata yang Anda sukai:</p>
//             <Table striped bordered hover responsive className="mt-4">
//                 <thead>
//                     <tr>
//                         <th>Jenis Wisata</th>
//                         <th>Peringkat</th>
//                     </tr>
//                 </thead>
//                 <tbody>
//                     {Object.keys(rankings).map((type) => (
//                         <tr key={type}>
//                             <td>{type.charAt(0).toUpperCase() + type.slice(1)}</td>
//                             <td>
//                                 <select
//                                     value={rankings[type]}
//                                     onChange={(e) => handleRankingChange(type, e.target.value)}
//                                     className="form-control"
//                                 >
//                                     <option value="0" disabled>Pilih Peringkat</option>
//                                     {getAvailableRankings(type).map(rank => (
//                                         <option key={rank} value={rank}>{rank}</option>
//                                     ))}
//                                 </select>
//                             </td>
//                         </tr>
//                     ))}
//                 </tbody>
//             </Table>
//             <div className="text-center mt-4">
//                 <Button variant="primary" onClick={handleSubmit}>
//                     Simpan Peringkat
//                 </Button>
//             </div>
//         </div>
//     );
// };

// export default RankingWisata;
