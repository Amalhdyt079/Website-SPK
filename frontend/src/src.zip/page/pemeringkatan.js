import React, { useState, useEffect } from "react";
import axios from "axios";

function CriteriaTable() {
  const [criterias, setCriterias] = useState([]);
  const [minValues, setMinValues] = useState({});
  const [maxValues, setMaxValues] = useState({});

  useEffect(() => {
    axios.get("/criterias").then((response) => {
      const data = response.data;
      setCriterias(data);

      const min = {};
      const max = {};
      data.forEach((criteria) => {
        min[criteria.id] = criteria.minValue;
        max[criteria.id] = criteria.maxValue;
      });
      setMinValues(min);
      setMaxValues(max);
    });
  }, []);

  return React.createElement(
    "div",
    null,
    React.createElement("h2", null, "Max/Min Nilai Kriteria"),
    React.createElement(
      "table",
      { border: "1" },
      React.createElement(
        "thead",
        null,
        React.createElement(
          "tr",
          null,
          React.createElement("th", null, "Kriteria"),
          React.createElement("th", null, "Max"),
          React.createElement("th", null, "Min")
        )
      ),
      React.createElement(
        "tbody",
        null,
        criterias.map((criteria) =>
          React.createElement(
            "tr",
            { key: criteria.id },
            React.createElement("td", null, criteria.name),
            React.createElement("td", null, maxValues[criteria.id]),
            React.createElement("td", null, minValues[criteria.id])
          )
        )
      )
    )
  );
}

export default CriteriaTable;
