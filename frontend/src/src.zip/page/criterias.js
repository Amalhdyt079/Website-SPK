import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Table } from 'react-bootstrap';
import axios from 'axios';

const Criterias = () => {

    const [criterias, setCriterias] = useState([]);

    useEffect(() => {
        // Fetch data from backend API
        axios.get('http://localhost:5000/criterias')
            .then(response => {
                setCriterias(response.data);
            })
            .catch(error => {
                console.error("There was an error fetching the kriteria data!", error);
            });
    }, []);

    return (
        <>
            <div className="hero min-vh-85 w-100 bg-dark text-white d-flex align-items-center">
                <Container>
                    <Row>
                        <Col>
                            <h1 className="text-center fs-1 animate__animated animate__bounce animate__fadeInUp">
                                KRITERIA WISATA DIY
                            </h1>
                            <p className="text-center text-white-50 animate__animated animate__fadeInUp animate__delay-1s">
                                Rekomendasi Tempat Wisata di Yogyakarta
                            </p>
                        </Col>
                    </Row>
                </Container>
            </div>
            
            <div className="container my-5">
            <h1 className="text-center mt-5" data-aos="fade-up">Data Kriteria</h1>
            <p>
            Dibahwa ini adalah data kriteria. Anda dapat mengisi data bobot sesuai dengan prefensi Anda  di Rekomendasi objek.
            </p>
                <Table striped bordered hover responsive>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kriteria</th>
                            <th>Atribut</th>
                        </tr>
                    </thead>
                    <tbody>
                        {criterias.map((criteria, index) => (
                            <tr key={criteria.id_kriteria}>
                                <td>{index + 1 }</td>
                                <td>{criteria.kriteria}</td>
                                <td>{criteria.atribut}</td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
            </div>
        </>
    );
};

export default Criterias;