import React, { useEffect, useState } from 'react';
import { Table } from 'react-bootstrap';


const Alternatives = ({ setAlternatives }) => {
    const [alternatives, setAlternativesState] = useState([]);

    useEffect(() => {
        // Contoh data yang diambil dari API atau database (misalnya, bisa menggunakan fetch)
        const fetchAlternatives = async () => {
            const response = await fetch('http://localhost:5000/alternatives'); // Ganti dengan API endpoint Anda
            const data = await response.json();
            setAlternativesState(data);
            setAlternatives(data); // Menyimpan data alternatif di parent component
        };
        fetchAlternatives();
    }, []);

    return (
        <div>
            <h2>Alternatives</h2>
            <Table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Harga</th>
                    </tr>
                </thead>
                <tbody>
                    {alternatives.map((alt) => (
                        <tr key={alt.id}>
                            <td>{alt.id_alternatif}</td>
                            <td>{alt.nama}</td>
                            <td>Rp {alt.harga} </td>
                        </tr>
                    ))}
                </tbody>
            </Table>
        </div>
    );
};

export default Alternatives;
