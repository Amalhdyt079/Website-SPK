import React, { useState, useEffect } from "react";
import axios from "axios";

const PreferenceCalculation = () => {
  const [preferences, setPreferences] = useState({});

  useEffect(() => {
    axios.get("/preference-values").then((response) => {
      setPreferences(response.data);
    });
  }, []);

  return (
    <div>
      <h2>Nilai Preferensi (P)</h2>
      <table border="1">
        <thead>
          <tr>
            <th>Alternatif</th>
            <th>Nilai Preferensi</th>
          </tr>
        </thead>
        <tbody>
          {Object.keys(preferences).map((altId) => (
            <tr key={altId}>
              <td>{altId}</td>
              <td>{preferences[altId].toFixed(4)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default PreferenceCalculation;
