import React, { useEffect, useState } from 'react';
import { Table } from 'react-bootstrap';

const Evaluations = ({ setEvaluations }) => {
    const [evaluations, setEvaluationsState] = useState([]);

    useEffect(() => {
        // Contoh data yang diambil dari API atau database (misalnya, bisa menggunakan fetch)
        const fetchEvaluations = async () => {
            const response = await fetch('http://localhost:5000/evaluations'); // Ganti dengan API endpoint Anda
            const data = await response.json();
            setEvaluationsState(data);  // Menyimpan data lokal
            setEvaluations(data);       // Menyimpan data ke state di parent
        };
        fetchEvaluations();
    }, [setEvaluations]); // Menambahkan setEvaluations dalam array dependensi

    return (
        <div>
            <h2>Evaluations</h2>
            <Table>
                <thead>
                    <tr>
                        <th>ID Alternatif</th>
                        <th>ID Kriteria</th>
                        <th>Nilai</th>
                    </tr>
                </thead>
                <tbody>
                    {evaluations.map((evalData) => (
                        <tr key={evalData.id}>
                            <td>{evalData.id_alternatif}</td>
                            <td>{evalData.id_kriteria}</td>
                            <td>{evalData.value}</td>
                        </tr>
                    ))}
                </tbody>
            </Table>
        </div>
    );
};

export default Evaluations;
