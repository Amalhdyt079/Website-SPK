import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Table, Button, Modal, Form, Spinner } from 'react-bootstrap';
import axios from 'axios';

const Alternatives = () => {
    const [alternatives, setAlternatives] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);
    const [newAlternative, setNewAlternative] = useState({ nama: '', deskripsi: '' });
    const [editAlternative, setEditAlternative] = useState(null);
    const [loading, setLoading] = useState(false);  // Loading state

    useEffect(() => {
        setLoading(true);  // Start loading when fetching data
        axios.get('http://localhost:5000/alternatives')
            .then(response => {
                setAlternatives(response.data);
                setLoading(false);  // Stop loading
            })
            .catch(error => {
                console.error("There was an error fetching the alternatives data!", error);
                setLoading(false);
            });
    }, []);

    const handleAddClick = () => {
        setShowModal(true);
    };

    const handleCloseModal = () => {
        setShowModal(false);
        setNewAlternative({ nama: '', deskripsi: '' });  // Reset form
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewAlternative({ ...newAlternative, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        setLoading(true);  // Start loading while submitting
        axios.post('http://localhost:5000/alternatives', newAlternative)
            .then(response => {
                setAlternatives(prev => [...prev, response.data.data]);
                setLoading(false);  // Stop loading
                handleCloseModal();
            })
            .catch(error => {
                console.error("There was an error adding the alternative!", error);
                setLoading(false);
            });
    };

    const handleEditClick = (alternative) => {
        setEditAlternative(alternative);
        setShowEditModal(true);
    };

    const handleCloseEditModal = () => {
        setShowEditModal(false);
        setEditAlternative(null);
    };

    const handleEditInputChange = (e) => {
        const { name, value } = e.target;
        setEditAlternative({ ...editAlternative, [name]: value });
    };

    const handleEditSubmit = (e) => {
        e.preventDefault();
        setLoading(true);  // Start loading while editing
        axios.put(`http://localhost:5000/alternatives/${editAlternative.id_alternatif}`, editAlternative)
            .then(response => {
                setAlternatives(alternatives.map(alternative =>
                    alternative.id_alternatif === editAlternative.id_alternatif ? response.data : alternative
                ));
                setLoading(false);  // Stop loading
                handleCloseEditModal();
            })
            .catch(error => {
                console.error("There was an error updating the alternative!", error);
                setLoading(false);
            });
    };

    const handleDeleteClick = (id) => {
        if (window.confirm("Apakah anda yakin ingin menghapusnya?")) {
            setLoading(true);  // Start loading while deleting
            axios.delete(`http://localhost:5000/alternatives/${id}`)
                .then(() => {
                    setAlternatives(alternatives.filter(alternative => alternative.id_alternatif !== id));
                    setLoading(false);  // Stop loading
                })
                .catch(error => {
                    console.error("There was an error deleting the alternative!", error);
                    setLoading(false);
                });
        }
    };

    return (
        <>
            <div className="hero min-vh-85 w-100 bg-dark text-white d-flex align-items-center">
                <Container>
                    <Row>
                        <Col>
                            <h1 className="text-center fs-1 animate__animated animate__bounce animate__fadeInUp">
                                ALTERNATIF WISATA DIY
                            </h1>
                            <p className="text-center text-white-50 animate__animated animate__fadeInUp animate__delay-1s">
                                Rekomendasi Tempat Wisata di Yogyakarta
                            </p>
                        </Col>
                    </Row>
                </Container>
            </div>

            <div className="container my-5">
                <h1 className="text-center mt-5" data-aos="fade-up">Data Alternatif</h1>
                <Button className="button-add" onClick={handleAddClick}>
                    Tambah
                </Button>
                <Table striped bordered hover responsive>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Jenis Wisata</th>
                            <th>Jarak</th>
                            <th>Harga</th>
                            <th>Rating</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            <tr>
                                <td colSpan="7" className="text-center">
                                    <Spinner animation="border" />
                                </td>
                            </tr>
                        ) : (
                            alternatives.map((alternative, index) => (
                                <tr key={alternative.id_alternatif}>
                                    <td>{index + 1}</td>
                                    <td>{alternative.nama}</td>
                                    <td>{alternative.jenis_wisata}</td>
                                    <td>{alternative.jarak}</td>
                                    <td>{alternative.harga}</td>
                                    <td>{alternative.rating}</td>
                                    <td>
                                        <div className="action-buttons">
                                            <Button variant="warning" onClick={() => handleEditClick(alternative)} className="btn-edit">
                                                Edit
                                            </Button>
                                            <Button variant="danger" onClick={() => handleDeleteClick(alternative.id_alternatif)} className="btn-delete">
                                                Delete
                                            </Button>
                                        </div>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </Table>
            </div>

            <Modal show={showModal} onHide={handleCloseModal}>
                <Modal.Header closeButton>
                    <Modal.Title>Tambah Data Alternatif</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleSubmit}>
                        <Form.Group controlId="formNama">
                            <Form.Label>Nama</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter name"
                                name="nama"
                                value={newAlternative.nama}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>

                        <Form.Group controlId="formDeskripsi">
                            <Form.Label>jenis_wisata</Form.Label>
                            <Form.Select
                                name="jenis_wisata"
                                value={newAlternative.deskripsi}
                                onChange={handleInputChange}
                                required
                            >
                                <option value="">Pilih Deskripsi</option>
                                <option value="Wisata Alam">Wisata Alam</option>
                                <option value="Sejarah">Wisata Sejarah</option>
                                <option value="Budaya">Wisata Budaya</option>
                            </Form.Select>
                        </Form.Group>
                        <Form.Group controlId="formNama">
                            <Form.Label>Jarak</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter name"
                                name="jarak"
                                value={newAlternative.nama}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="formNama">
                            <Form.Label>Harga</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter name"
                                name="harga"
                                value={newAlternative.nama}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="formNama">
                            <Form.Label>Rating</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter name"
                                name="rating"
                                value={newAlternative.nama}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>
                        <br />
                        <Button variant="primary" type="submit">
                            Tambah
                        </Button>
                    </Form>
                </Modal.Body>
            </Modal>

            <Modal show={showEditModal} onHide={handleCloseEditModal}>
                <Modal.Header closeButton>
                    <Modal.Title>Edit Data Alternatif</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {editAlternative && (
                        <Form onSubmit={handleEditSubmit}>
                            <Form.Group controlId="formEditNama">
                                <Form.Label>Nama</Form.Label>
                                <Form.Control
                                    type="text"
                                    placeholder="Enter name"
                                    name="nama"
                                    value={editAlternative.nama}
                                    onChange={handleEditInputChange}
                                    required
                                />
                            </Form.Group>

                            <Form.Group controlId="formEditDeskripsi">
                                <Form.Label>jenis_wisata</Form.Label>
                                <Form.Select
                                    name="jenis_wisata"
                                    value={editAlternative.deskripsi}
                                    onChange={handleEditInputChange}
                                    required
                                >
                                    <option value="">Pilih Deskripsi</option>
                                    <option value="Wisata Alam">Wisata Alam</option>
                                    <option value="Wisata Sejarah">Wisata Sejarah</option>
                                    <option value="Wisata Budaya">Wisata Budaya</option>
                                </Form.Select>
                                <Form.Group controlId="formNama">
                                    <Form.Label>Jarak</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Enter name"
                                        name="jarak"
                                        value={newAlternative.nama}
                                        onChange={handleInputChange}
                                        required
                                    />
                                </Form.Group>
                                <Form.Group controlId="formNama">
                                    <Form.Label>Harga</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Enter name"
                                        name="harga"
                                        value={newAlternative.nama}
                                        onChange={handleInputChange}
                                        required
                                    />
                                </Form.Group>
                                <Form.Group controlId="formNama">
                                    <Form.Label>Rating</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Enter name"
                                        name="rating"
                                        value={newAlternative.nama}
                                        onChange={handleInputChange}
                                        required
                                    />
                                </Form.Group>
                            </Form.Group><br />
                            <Button variant="primary" type="submit">
                                Save Changes
                            </Button>
                        </Form>
                    )}
                </Modal.Body>
            </Modal>
        </>
    );
};

export default Alternatives;
