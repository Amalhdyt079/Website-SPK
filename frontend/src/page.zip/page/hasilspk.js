import React, { useState, useEffect } from 'react';
import { Table, Button } from 'react-bootstrap';
import axios from 'axios';

const RekomendasiObjek = () => {
    const [criterias, setCriterias] = useState([]);
    const [rankings, setRankings] = useState({
        "Wisata Sejarah": 0,
        "Wisata Budaya": 0,
        "Wisata Alam": 0,
    });
    const [loading, setLoading] = useState(false);
    const [recommendations, setRecommendations] = useState([]);

    useEffect(() => {
        // Fetch data from backend API
        axios.get('http://localhost:5000/criterias')
            .then(response => {
                console.log("Fetched criterias:", response.data); // Debugging log
                setCriterias(response.data);
            })
            .catch(error => {
                console.error("Error fetching kriteria data!", error);
            });
    }, []);

    const calculateTotalWeight = () => {
        return criterias.reduce((total, criteria) => total + parseFloat(criteria.bobot || 0), 0);
    };

    const handleWeightChange = (id, value) => {
        const newWeight = parseFloat(value) || 0; // Nilai default jika input kosong
        const currentTotal = calculateTotalWeight();

        // Dapatkan bobot kriteria yang sedang diedit
        const currentCriteria = criterias.find(criteria => criteria.id_kriteria === id);
        if (!currentCriteria) return;

        // Validasi: Pastikan total bobot tidak melebihi 1
        const updatedTotal = currentTotal - (parseFloat(currentCriteria.bobot) || 0) + newWeight;
        if (updatedTotal > 1) {
            alert('Total bobot semua kriteria tidak boleh melebihi 1!');
            return;
        }

        // Perbarui bobot kriteria
        const updatedCriterias = criterias.map(criteria => {
            if (criteria.id_kriteria === id) {
                return { ...criteria, bobot: newWeight };
            }
            return criteria;
        });
        setCriterias(updatedCriterias);
    };

    const handleSubmitCriteria = () => {
        return axios.put('http://localhost:5000/criterias', criterias);
    };

    const handleRankingChange = (type, value) => {
        const newValue = parseInt(value, 10);

        // Check if the new value is valid and unique
        if (newValue < 1 || newValue > 3) {
            return; // Ignore invalid values
        }

        // Check if the new value already exists in other rankings
        const existingRankings = Object.values(rankings).filter(
            (rank) => rank !== 0 && rank !== newValue
        );

        if (existingRankings.includes(newValue)) {
            alert(`Peringkat ${newValue} sudah dipilih untuk jenis wisata lain!`);
            return; // Prevent setting this ranking
        }

        setRankings(prevRankings => ({
            ...prevRankings,
            [type]: newValue,
        }));
    };

    const handleSubmitRanking = () => {
        return axios.post('http://localhost:5000/api/rankings', rankings);
    };

    const handleSubmit = async () => {
        setLoading(true);
        try {
            await handleSubmitCriteria();
            alert('Data kriteria berhasil disimpan!');
            await handleSubmitRanking();
            alert('Ranking berhasil disimpan!');
            calculateRecommendations(); // Trigger recommendations calculation after saving
        } catch (error) {
            console.error("Error saving data:", error);
            alert('Terjadi kesalahan saat menyimpan data!');
        } finally {
            setLoading(false);
        }
    };

    const getAvailableRankings = (currentType) => {
        const usedRanks = Object.entries(rankings)
            .filter(([type]) => type !== currentType && rankings[type] > 0)
            .map(([_, rank]) => rank);

        return [1, 2, 3].filter(rank => !usedRanks.includes(rank));
    };

    const calculateRecommendations = () => {
        const alternatives = [
            { name: "Wisata Sejarah", attributes: { accessibility: 4, cost: 3, popularity: 5 } },
            { name: "Wisata Budaya", attributes: { accessibility: 5, cost: 2, popularity: 4 } },
            { name: "Wisata Alam", attributes: { accessibility: 3, cost: 4, popularity: 5 } },
        ];

        // Calculate scores for each alternative
        const scores = alternatives.map(alt => {
            let score = 0;
            criterias.forEach(criteria => {
                const weight = parseFloat(criteria.bobot || 0);
                const attributeValue = alt.attributes[criteria.kriteria.toLowerCase()];
                if (attributeValue !== undefined) {
                    score += weight * attributeValue; // Weighted sum
                } else {
                    console.warn(`Attribute ${criteria.kriteria.toLowerCase()} not found for ${alt.name}`);
                }
            });
            return { name: alt.name, score };
        });

        // Sort recommendations by score
        scores.sort((a, b) => b.score - a.score); // Descending order
        console.log("Calculated scores:", scores); // Debugging log
        setRecommendations(scores); // Set recommendations state
    };

    return (
        <div className="container my-5">
            <h1 className="text-center mt-5">Isi Bobot Kriteria dan Peringkat Wisata</h1><br />

            <p>
                Sesuaikan bobot masing-masing kriteria sesuai dengan tingkat kepentingannya bagi Anda.
                Berikan bobot yang mencerminkan prioritas Anda pada setiap kriteria.
                Namun pastikan total bobotnya tidak melebihi 1.
            </p>

            <div className="row mt-4">
                {/* Tabel Bobot Kriteria */}
                <div className="col-md-6">
                    <h4>Kriteria dan Bobot</h4>
                    <Table striped bordered hover responsive>
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kriteria</th>
                                <th>Bobot
                                    <h6 style={{ fontSize: 'small', margin: 0 }}>Total Bobot (Max 1) : {calculateTotalWeight().toFixed(2)}</h6>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            {criterias.map((criteria, index) => (
                                <tr key={criteria.id_kriteria}>
                                    <td>{index + 1}</td>
                                    <td>{criteria.kriteria}</td>
                                    <td>
                                        <input
                                            type="number"
                                            step="0.01"
                                            min="0"
                                            max="1"
                                            value={criteria.bobot}
                                            onChange={(e) => handleWeightChange(criteria.id_kriteria, e.target.value)}
                                            className="form-control"
                                        />
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>

                </div>

                {/* Tabel Peringkat Wisata */}
                <div className="col-md-6">
                    <h4>Peringkat Jenis Wisata</h4>
                    <Table striped bordered hover responsive>
                        <thead>
                            <tr>
                                <th>Jenis Wisata</th>
                                <th>Peringkat</th>
                            </tr>
                        </thead>
                        <tbody>
                            {Object.keys(rankings).map((type) => (
                                <tr key={type}>
                                    <td>{type}</td>
                                    <td>
                                        <select
                                            value={rankings[type]}
                                            onChange={(e) => handleRankingChange(type, e.target.value)}
                                            className="form-control"
                                        >
                                            <option value="0" disabled>Pilih Peringkat</option>
                                            {getAvailableRankings(type).map(rank => (
                                                <option key={rank} value={rank}>{rank}</option>
                                            ))}
                                        </select>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </div>
            </div>

            {/* Recommendations Display */}

            {recommendations.length > 0 && (

                <div className="mt-5">

                    <h4>Rekomendasi Objek Wisata</h4>

                    <Table striped bordered hover responsive>

                        <thead>

                            <tr>

                                <th>Nama Wisata</th>

                                <th>Score</th>

                            </tr>

                        </thead>

                        <tbody>

                            {recommendations.map((rec) => (

                                <tr key={rec.name}>

                                    <td>{rec.name}</td>

                                    <td>{rec.score.toFixed(2)}</td>

                                </tr>

                            ))}

                        </tbody>

                    </Table>

                </div>

            )}



            {/* Submit Button */}

            <div className="text-center mt-4">

                <Button variant="primary" onClick={handleSubmit} disabled={loading}>

                    {loading ? 'Menyimpan...' : 'Search'}

                </Button>

            </div>

        </div>

    );

}



export default RekomendasiObjek;