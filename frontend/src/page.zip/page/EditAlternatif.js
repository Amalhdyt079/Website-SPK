// from flask_restful import Resource 
// from models.criteria import Criteria
// from models.alternative import Alternative
// from models.calculate import Calculate

// class SAWCalculation(Resource):
//     def get(self):
//         # Ambil data dari database
//         criteria_data = {
//             c.criteria: {"atribut": c.atribut, "bobot": c.bobot} for c in Criteria.query.all()
//         }
//         alternatives = {
//             a.id: {"nama": a.nama, "atribut": a.atribut} for a in Alternative.query.all()
//         }
//         nilai_alternatif = {
//             (n.alternative_id, crit.criteria): n.value
//             for n, crit in Calculate.query.join(Criteria, Criteria.id == Calculate.criteria_id).with_entities(Calculate, Criteria).all()
//         }


//         # Buat matriks keputusan
//         matriks_keputusan = {}
//         for alt_id, alt_data in alternatives.items():
//             matriks_keputusan[alt_id] = {
//                 k: nilai_alternatif.get((alt_id, k), 0) for k in criteria_data
//             }

//         # Normalisasi matriks keputusan
//         matriks_normalisasi = {}
//         for alt, nilai in matriks_keputusan.items():
//             matriks_normalisasi[alt] = {}
//             for krit, val in nilai.items():
//                 if krit in criteria_data:
//                     if criteria_data[krit]["atribut"] == "benefit":
//                         matriks_normalisasi[alt][krit] = val / max(
//                             [n[krit] for n in matriks_keputusan.values()]
//                         )
//                     else:
//                         matriks_normalisasi[alt][krit] = min(
//                             [n[krit] for n in matriks_keputusan.values()]
//                         ) / val

//         # Kalkulasi skor akhir
//         skor_akhir = {}
//         for alt, nilai in matriks_normalisasi.items():
//             skor_akhir[alt] = sum(
//                 [nilai[krit] * criteria_data[krit]["bobot"] for krit in criteria_data]
//             )

//         # Pisahkan hasil peringkat berdasarkan atribut alternatif
//         Dimas = []
//         Diajeng = []
//         for alt_id, skor in skor_akhir.items():
//             alt = alternatives[alt_id]
//             if alt["atribut"] == "Dimas":
//                 Dimas.append({"nama": alt["nama"], "skor": skor})
//             else:
//                 Diajeng.append({"nama": alt["nama"], "skor": skor})

//         # Urutkan masing-masing kategori berdasarkan skor
//         Dimas = sorted(Dimas, key=lambda x: x["skor"], reverse=True)
//         Diajeng = sorted(Diajeng, key=lambda x: x["skor"], reverse=True)

//         # Tambahkan peringkat untuk setiap kategori
//         for rank, item in enumerate(Dimas, start=1):
//             item["peringkat"] = rank
//         for rank, item in enumerate(Diajeng, start=1):
//             item["peringkat"] = rank

//         # Return hasil dalam format JSON
//         return {
//             "Dimas": Dimas,
//             "Diajeng": Diajeng
//         }, 200