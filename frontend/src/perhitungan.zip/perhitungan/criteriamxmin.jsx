import React, { useState, useEffect } from "react";
import axios from "axios";

const CriteriaTable = () => {
  const [criterias, setCriterias] = useState([]);
  const [minValues, setMinValues] = useState({});
  const [maxValues, setMaxValues] = useState({});

  useEffect(() => {
    axios.get("http://localhost:5000/criterias").then((response) => {
      const data = response.data;
      setCriterias(data);

      const min = {};
      const max = {};
      data.forEach((criteria) => {
        min[criteria.id] = criteria.minValue;
        max[criteria.id] = criteria.maxValue;
      });
      setMinValues(min);
      setMaxValues(max);
    });
  }, []);

  return (
    <div>
      <h2>Max/Min Nilai Kriteria</h2>
      <table border="1">
        <thead>
          <tr>
            <th>Kriteria</th>
            <th>Max</th>
            <th>Min</th>
          </tr>
        </thead>
        <tbody>
          {criterias.map((criteria) => (
            <tr key={criteria.id}>
              <td>{criteria.name}</td>
              <td>{maxValues[criteria.id]}</td>
              <td>{minValues[criteria.id]}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CriteriaTable;
