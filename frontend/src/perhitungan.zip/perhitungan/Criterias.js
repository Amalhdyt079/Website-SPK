import React, { useEffect, useState } from 'react';
import { Table } from 'react-bootstrap';


const Criterias = ({ setCriterias, setWeights }) => {
    const [criterias, setCriteriasState] = useState([]);

    useEffect(() => {
        const fetchCriterias = async () => {
            const response = await fetch('http://localhost:5000/criterias');
            const data = await response.json();
            setCriteriasState(data);
            setCriterias(data);
            console.log("Fetched Criterias:", data); // Log the fetched data
    
            const weights = data.reduce((acc, criteria) => {
                acc[criteria.id_kriteria] = criteria.bobot; // Ensure this matches your data structure
                return acc;
            }, {});
            setWeights(weights);
        };
        fetchCriterias();
    }, []);

    return (
        <div>
            <h2>Criterias</h2>
            <Table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama</th>
                        <th>Jenis</th>
                        <th>Bobot</th>
                    </tr>
                </thead>
                <tbody>
                    {criterias.map((criteria) => (
                        <tr key={criteria.id_}>
                            <td>{criteria.id_kriteria}</td>
                            <td>{criteria.kriteria}</td>
                            <td>{criteria.bobot}</td>
                            <td>{criteria.atribut}</td>
                        </tr>
                    ))}
                </tbody>
            </Table>
        </div>
    );
};

export default Criterias;
