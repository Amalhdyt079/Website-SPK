import React, { useState, useEffect } from "react";
import axios from "axios";

const NormalizationMatrix = () => {
  const [matrix, setMatrix] = useState({});
  const [criterias, setCriterias] = useState([]);

  useEffect(() => {
    axios.get("/normalization-matrix").then((response) => {
      setMatrix(response.data.matrix);
      setCriterias(response.data.criterias);
    });
  }, []);

  return (
    <div>
      <h2>Matriks Normalisasi (R)</h2>
      <table border="1">
        <thead>
          <tr>
            <th>Alternatif</th>
            {criterias.map((criteria) => (
              <th key={criteria.id}>{criteria.name}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {Object.keys(matrix).map((altId) => (
            <tr key={altId}>
              <td>{altId}</td>
              {criterias.map((criteria) => (
                <td key={criteria.id}>{matrix[altId][criteria.id].toFixed(4)}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default NormalizationMatrix;
