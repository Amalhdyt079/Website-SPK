# from flask_jwt_extended import JWTManager

# def config_auth(app):
#     global jwt
#     app.config['JWT_SECRET_KEY'] = 'rahasia'
#     jwt = JWTManager(app)